/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Barang2;

/**
 *
 * @author ampun
 */
public class Barang2 {
      /**
     * @param args the command line arguments
     */
     public static void main(String[] args) {
        // TODO code application logic here
       barangBarang[] brng = new barangBarang[2];
        
        brng[0] = new barangBarang("B001", "BUKU GAMBAR", 2500, 3000, 5, 2);
        brng[1] = new barangBarang("p002", "PENSIL 2B", 1500, 1750, 10, 1);
        
        for(int i = 0; i < brng.length; i++){
            System.out.println(brng[i].tampilinHasilPenjualanBarang());
            System.out.println("---------------------------------------------------");
        }
        
}
}
