/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Barang2;

/**
 *
 * @author ASUS
 */
 class Barang1 extends barangBarang {

    public Barang1(String kodeBarang, String namaBarang, int HPP, int hargaJual, int stok, int jumlahJual) {
        super(kodeBarang, namaBarang, HPP, hargaJual, stok, jumlahJual);
    }
}
