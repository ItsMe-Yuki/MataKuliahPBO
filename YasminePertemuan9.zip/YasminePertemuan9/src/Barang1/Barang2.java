/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Barang1;

/**
 *
 * @author ASUS
 */
public class Barang2 {
    public static void main(String[] args) {
    BukuGambar coba = new BukuGambar("B001", "BUKU GAMBAR", 2500, 3000, 5, 2);
        
    System.out.println(coba.tampilHasilPenjualanBarang());
        
        
    }
}
